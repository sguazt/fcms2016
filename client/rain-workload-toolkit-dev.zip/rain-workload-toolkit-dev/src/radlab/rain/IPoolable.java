package radlab.rain;

public interface IPoolable 
{
	void cleanup() throws Exception;
}
