package radlab.rain.workload.mongodb;

public class MongoRequest<T> 
{
	public T key;
	public int op;
	public int size;
	public byte[] value;
}
