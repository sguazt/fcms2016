package radlab.rain.hotspots;

import java.util.ArrayList;

public class PopularityProfile<O> {
	@SuppressWarnings("unused")
	private ArrayList<IObjectGenerator<O>> profile;
	
	public PopularityProfile(Multinomial m) {
		
	}
	
	
}
