#!/bin/sh

java -cp . TDigestClient $*
