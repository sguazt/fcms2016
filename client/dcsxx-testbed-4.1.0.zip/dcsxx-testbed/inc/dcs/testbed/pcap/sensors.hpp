/**
 * \file dcs/testbed/pcap/sensors.hpp
 *
 * \brief Sensor for retrieving application information by means of libpcap.
 *
 * \author Marco Guazzone (marco.guazzone@gmail.com)
 *
 * <hr/>
 *
 * Copyright 2012 Marco Guazzone (marco.guazzone@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef DCS_TESTBED_PCAP_SENSORS_HPP
#define DCS_TESTBED_PCAP_SENSORS_HPP


#include <dcs/debug.hpp>
#include <dcs/exception.hpp>
#include <dcs/testbed/base_sensor.hpp>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/client_simple.hpp>


namespace dcs { namespace testbed { namespace pcap {

namespace detail { namespace /*<unnamed>*/ {

inline
::std::string make_url(::std::string const& host, unsigned int port)
{
	::std::ostringstream oss;
	oss << "http://" << host << ":" << port;
	return oss.str();
}

inline
template <typename T>
::std::string to_string(T val)
{
	::std::ostreamstream oss;
	oss << val;
	return oss.str();
}

inline
::std::string to_string(connection_status_category status)
{
	return to_string(static_cast<int>(status));
}

inline
::std::string to_string(::xmlrpc_c::value::type_t type)
{
	switch (type)
	{
		case ::xmlrpc_c::value::TYPE_INT:
			return "int";
		case ::xmlrpc_c::value::TYPE_BOOLEAN:
			return "bool";
		case ::xmlrpc_c::value::TYPE_DOUBLE:
			return "double";
		case ::xmlrpc_c::value::TYPE_DATETIME:
			return "datetime";
		case ::xmlrpc_c::value::TYPE_STRING:
			return "string";
		case ::xmlrpc_c::value::TYPE_BYTESTRING:
			return "bytestring";
		case ::xmlrpc_c::value::TYPE_ARRAY:
			return "array";
		case ::xmlrpc_c::value::TYPE_STRUCT:
			return "struct";
		case ::xmlrpc_c::value::TYPE_C_PTR:
			return "c_ptr";
		case ::xmlrpc_c::value::TYPE_NIL:
			return "nil";
		case ::xmlrpc_c::value::TYPE_I8:
			return "i8";
		case ::xmlrpc_c::value::TYPE_DEAD:
			return "dead";
	}

	DCS_EXCEPTION_THROW(::std::runtime_error, "Unknown XML-RPC type.");
}

class xmlrpc_client
{
	public: static const ::std::string default_server_host;
	public: static const unsigned int default_server_port;


	public: explicit xmlrpc_client(::std::string const& srv_host = default_server_host,
								   unsigned int srv_port = default_server_port,
								   ::std::string const& mon_host = srv_host,
								   unsigned int mon_port = srv_port)
	: srv_host_(srv_host),
	  srv_port_(srv_port),
	  mon_host_(mon_host),
	  mon_port_(mon_port),
	  url(detail::make_url(srv_host, srv_port))
	{
	}

	public: ::std::string server_hostname() const
	{
		return srv_host_;
	}

	public: unsigned int server_port() const
	{
		return srv_port_;
	}

	public: unsigned int num_tcp_connections(::std::string const& host,
											 unsigned int port,
											 connection_status_category status)
	{
		xmlrpc_c::clientSimple rpc;

		xmlrpc_c::value res;
		rpc.call(url_,
				 "num_tcp_connections",
				 "sss",
				 &res,
				 host.c_str(),
				 to_string(port).c_str(),
				 to_string(status).c_str());

		if (res.type() != xmlrpc_c::value::TYPE_INT)
		{
			::std::ostringstream oss;
			oss << "Expected type '" << to_string(xmlrpc_c::value::TYPE_INT) << "' (" << xmlrpc_c::value::TYPE_INT << "), got type '" << to_string(res.type()) << "' (" << res.type() << ").";
			DCS_EXCEPTION_THROW(::std::runtime_error, oss.str());
		}
	}


	private: ::std::string srv_host_; ///< The name of the XML-RPC server host
	private: unsigned int srv_port_; ///< The port at which the XML-RPC server is listening
	private: ::std::string mon_host_; ///< The name of the monitored host
	private: unsigned int mon_port_; ///< The port at which the monitored host is listening
	private: ::std::string url_;
}; // xmlrpc_client

const ::std::string xmlrpc_client::default_server_host("localhost");

const unsigned int xmlrpc_client::default_server_port = 9999;

}} // Namespace detail::<unnamed>


template <typename TraitsT>
class queue_length_sensor: public base_sensor<TraitsT>
{
	private: typedef base_sensor<TraitsT> base_type;
	public: typedef typename base_type::traits_type traits_type;
	public: typedef typename base_type::observation_type observation_type;


	public: queue_length_sensor(::std::string const& host, unsigned int port)
	: rpc_(host, port)
	{
	}

	public: ::std::string server_hostname() const
	{
		return rpc_.server_hostname();
	}

	public: unsigned short server_port() const
	{
		return rpc_.server_port();
	}

	private: void do_sense()
	{
		DCS_DEBUG_TRACE("BEGIN Do Sense");

		obs_.clear();

		DCS_DEBUG_TRACE("END Do Sense");
	}


	private: ::std::string srv_addr_; ///< The server IP address or hostname.
	private: unsigned short srv_port_; ///< The server port.
	private: detail::xmlrpc_client rpc_;
	private: ::std::vector<observation_type> obs_;
}; // queue_length_sensor

}}} // Namespace dcs::stestbed::pcap

#endif // DCS_TESTBED_PCAP_SENSORS_HPP
