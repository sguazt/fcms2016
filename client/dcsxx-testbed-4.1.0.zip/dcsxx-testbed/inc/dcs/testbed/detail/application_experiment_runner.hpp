/**
 * \file dcs/testbed/detail/application_experiment.hpp
 *
 * \brief Represents an experiment for a single application.
 *
 * \author Marco Guazzone (marco.guazzone@gmail.com)
 *
 * <hr/>
 *
 * Copyright 2012 Marco Guazzone (marco.guazzone@gmail.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef DCS_TESTBED_DETAIL_APPLICATION_EXPERIMENT_RUNNER_HPP
#define DCS_TESTBED_DETAIL_APPLICATION_EXPERIMENT_RUNNER_HPP


#include <boost/bind.hpp>
#include <boost/chrono.hpp>
#include <boost/smart_ptr.hpp>
#include <boost/thread.hpp>
#include <dcs/assert.hpp>
#include <dcs/debug.hpp>
#include <dcs/exception.hpp>
#include <dcs/testbed/application_experiment.hpp>
#include <dcs/testbed/detail/runnable.hpp>
#include <stdexcept>


namespace dcs { namespace testbed { namespace detail {

template <typename T, typename MT>
struct sampler_runnable
{
	sampler_runnable(::boost::weak_ptr<T> const& ptr, MT& mutex)
	: wp_(ptr),
	  mtx_(mutex)
	{
	}

	void operator()()
	{
		DCS_DEBUG_TRACE("SAMPLER THREAD: Entering...");

		::boost::shared_ptr<T> sp(wp_.lock());

		// Transform secs into millisecs so that the conversion real->uint keeps some decimal
		typename T::traits_type::uint_type ts = 1000.0*sp->sampling_time();
 
		// Loop forever until we get interrupted
		while (true)
		{
			{
				::boost::lock_guard< ::boost::mutex > lock(mtx_);

				sp->sample();
			}

			::boost::this_thread::sleep_for(::boost::chrono::milliseconds(ts));
		}

		DCS_DEBUG_TRACE("SAMPLER THREAD: Leaving...");
	}

	::boost::weak_ptr<T> wp_;
	MT& mtx_;
}; // sampler_runnable

template <typename T, typename MT>
struct controller_runnable
{
	controller_runnable(::boost::weak_ptr<T> const& ptr, MT& mutex)
	: wp_(ptr),
	  mtx_(mutex)
	{
	}

	void operator()()
	{
		DCS_DEBUG_TRACE("CONTROLLER THREAD: Entering...");

		::boost::shared_ptr<T> sp(wp_.lock());

		// Transform secs into millisecs so that the conversion real-> uint keeps some decimal
		typename T::traits_type::uint_type ts = 1000.0*sp->control_time();
 
		// Loop forever until we get interrupted
		while (true)
		{
			{
				::boost::lock_guard< ::boost::mutex > lock(mtx_);

				sp->control();
			}

			::boost::this_thread::sleep_for(::boost::chrono::milliseconds(ts));
		}

		DCS_DEBUG_TRACE("CONTROLLER THREAD: Leaving...");
	}

	::boost::weak_ptr<T> wp_;
	MT& mtx_;
}; // controller_runnable

/*
template <typename T, typename MT>
struct monitor_runnable
{
	monitor_runnable(::boost::weak_ptr<T> const& ptr, MT& mutex)
	: wp_(ptr),
	  mtx_(mutex)
	{
	}

	void operator()()
	{
		DCS_DEBUG_TRACE("MONITOR THREAD: Entering...");

		::boost::shared_ptr<T> sp(wp_.lock());

		// Transform secs into millisecs so that the conversion real -> uint keeps some decimal
		typename T::traits_type::uint_type ts = 1000.0*sp->monitoring_time();

		// Loop forever until we get interrupted
		while (true)
		{
			{
				::boost::lock_guard< ::boost::mutex > lock(mtx_);

				sp->monitor();
			}

			::boost::this_thread::sleep_for(::boost::chrono::milliseconds(ts));
		}

		DCS_DEBUG_TRACE("MONITOR THREAD: Leaving...");
	}


	::boost::weak_ptr<T> wp_;
	MT& mtx_;
}; // monitor_runnable
*/

template <typename TraitsT>
class application_experiment_runner
{
	public: typedef TraitsT traits_type;
	public: typedef typename traits_type::real_type real_type;
	private: typedef application_experiment<traits_type> experiment_type;
	public: typedef ::boost::shared_ptr<experiment_type> experiment_pointer;
	private: typedef base_application<traits_type> app_type;
	public: typedef ::boost::shared_ptr<app_type> app_pointer;
	private: typedef base_workload_driver<traits_type> driver_type;
	public: typedef ::boost::shared_ptr<driver_type> driver_pointer;
	private: typedef base_application_manager<traits_type> manager_type;
	public: typedef ::boost::shared_ptr<manager_type> manager_pointer;


	public: application_experiment_runner(experiment_pointer const& p_exp)
	: p_exp_(p_exp)
	{
	}

	public: void run()
	{
		DCS_ASSERT(p_exp_->app_ptr(),
				   DCS_EXCEPTION_THROW(::std::runtime_error,
									   "Application not set"));
		DCS_ASSERT(p_exp_->driver_ptr(),
				   DCS_EXCEPTION_THROW(::std::runtime_error,
									   "Driver not set"));
		DCS_ASSERT(p_exp_->manager_ptr(),
				   DCS_EXCEPTION_THROW(::std::runtime_error,
									   "Manager not set"));

//		typedef typename monitor_container::iterator monitor_iterator;

		const unsigned long zzz_time(5);

		p_exp_->manager()->app(p_exp_->app_ptr());
		p_exp_->manager()->reset();
		p_exp_->driver_ptr()->app(p_exp_->app_ptr());
		p_exp_->driver_ptr()->reset();
//		monitor_iterator mon_beg_it(mons_.begin());
//		monitor_iterator mon_end_it(mons_.end());
//		for (monitor_iterator mon_it = mon_beg_it;
//			 mon_it != mon_end_it;
//			 ++mon_it)
//		{
//			mon_it->app(p_exp_->app_ptr());
//			mon_it->reset();
//		}

		p_exp_->driver_ptr()->start();

		::boost::thread_group mgr_thd_grp;
		::boost::mutex mgr_mtx;
		bool mgr_run(false);
		while (!p_exp_->driver_ptr()->done())
		{
			if (!mgr_run && p_exp_->driver_ptr()->ready())
			{
				sampler_runnable<manager_type,::boost::mutex> mgr_smp_runner(p_exp_->manager_ptr(), mgr_mtx);
				mgr_thd_grp.create_thread(mgr_smp_runner);

				controller_runnable<manager_type,::boost::mutex> mgr_ctl_runner(p_exp_->manager_ptr(), mgr_mtx);
				mgr_thd_grp.create_thread(mgr_ctl_runner);

//				for (monitor_iterator mon_it = mon_beg_it;
//					 mon_it != mon_end_it;
//					 ++mon_it)
//				{
//					monitor_runnable<monitor_type,::boost::mutex> mgr_mon_runner(*mon_it, mgr_mtx);
//					mgr_thd_grp.create_thread(mgr_mon_runner);
//				}

				mgr_run = true;
			}

			::boost::this_thread::sleep_for(::boost::chrono::seconds(zzz_time));
		}

		mgr_thd_grp.interrupt_all();
		mgr_thd_grp.join_all();

		p_exp_->driver_ptr()->stop();
	}


	private: experiment_pointer p_exp_; ///< Pointer to the application experiment
}; // application_experiment_runner

}}} // Namespace dcs::testbed::detail

#endif // DCS_TESTBED_DETAIL_APPLICATION_EXPERIMENT_RUNNER_HPP
