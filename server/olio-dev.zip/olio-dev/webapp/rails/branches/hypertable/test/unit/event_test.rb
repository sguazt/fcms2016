require File.dirname(__FILE__) + '/../test_helper'

class EventTest < Test::Unit::TestCase
  fixtures :events

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
